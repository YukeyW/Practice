//
//  ForecastService.swift
//  Weather
//
//  Created by yukey on 21/7/20.
//  Copyright © 2020 Yukey. All rights reserved.
//

import Foundation

class ForecastService {
    let forecastAPIKey: String
    let forecastBaseURL:  URL?
    
    init(APIKey: String) {
        self.forecastAPIKey = APIKey
        forecastBaseURL = URL(string: "https://api.openweathermap.org/data/2.5/weather?")
    }
    
    func getForecast(latitude: Double, longitude: Double, completion: @escaping (CurrentWeather?) -> Void) {
        if let forecastURL = URL(string: "\(forecastBaseURL!)lat=\(latitude)&lon=\(longitude)&appid=\(forecastAPIKey)") {
            
            let networkProcessor = NetworkProcessor(url: forecastURL)
            networkProcessor.downloadJSONFromURL({ (jsonDictionary) in
                
                if let currentWeatherdictionary = jsonDictionary?["main"] as? [String: Any] {
                    let currentWeather = CurrentWeather(weatherDictionary: currentWeatherdictionary)
                    completion(currentWeather)
                } else {
                    completion(nil)
                }
            })
        }
    }
    
    
}
