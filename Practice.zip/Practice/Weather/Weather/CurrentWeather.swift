//
//  CurrentWeather.swift
//  Weather
//
//  Created by yukey on 22/7/20.
//  Copyright © 2020 Yukey. All rights reserved.
//

import Foundation

class CurrentWeather {
    let temperature: Int?
    let humidity: Int?
    
    init(weatherDictionary: [String: Any]) {
        temperature = Int(weatherDictionary["temp"] as! Double - 273.15)
        
        humidity = weatherDictionary["humidity"] as? Int
    }
    
}
