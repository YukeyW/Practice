//
//  ViewController.swift
//  Quiz
//
//  Created by yukey on 16/7/20.
//  Copyright © 2020 Yukey. All rights reserved.
//

import UIKit
import ProgressHUD

class ViewController: UIViewController {
    @IBOutlet weak var questionNo: UILabel!
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var width: NSLayoutConstraint!
    @IBOutlet weak var question: UILabel!
    @IBOutlet weak var flagImage: UIImageView!
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionC: UIButton!
    @IBOutlet weak var optionD: UIButton!
    let questionList = QuestionBank()
    var count = 0
    var scoreNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }

    @IBAction func clickButton(_ sender: UIButton) {
        if sender.tag + 1 == questionList.list[count-1].correctAnswer {
            ProgressHUD.showSuccess("Correct")
            scoreNum += 1
        } else {
            ProgressHUD.showError("Incorrect")
        }
        updateUI()
    }
    
    func updateUI() {
        count += 1
        if count <= questionList.list.count {
            questionNo.text = "\(count)/" + "\(questionList.list.count)"
            score.text = "Score: \(scoreNum)"
            width.constant = CGFloat((Int(view.frame.size.width) / questionList.list.count) * count)
            question.text = questionList.list[count-1].question
            flagImage.image = UIImage(named: questionList.list[count-1].questionImage)
            optionA.setTitle(questionList.list[count-1].optionA, for: UIControl.State.normal)
            optionB.setTitle(questionList.list[count-1].optionB, for: UIControl.State.normal)
            optionC.setTitle(questionList.list[count-1].optionC, for: UIControl.State.normal)
            optionD.setTitle(questionList.list[count-1].optionD, for: UIControl.State.normal)
        }
        if count == 6 {
            let alert =  UIAlertController(title: "Awesome", message: "End of Quiz. Do you want to start over?", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.quizStart()})
            alert.addAction(restartAction)
            present(alert, animated: true, completion: nil)
        }
    }
    
    func quizStart() {
        count = 0
        scoreNum = 0
        updateUI()
    }
}

