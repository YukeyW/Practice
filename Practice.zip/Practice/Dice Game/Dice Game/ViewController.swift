//
//  ViewController.swift
//  Dice Game
//
//  Created by yukey on 15/7/20.
//  Copyright © 2020 Yukey. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var leftImage: UIImageView!
    @IBOutlet weak var rightImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func clickButton(_ sender: UIButton) {
        let firstNumber = arc4random_uniform(5) + 1
        let secondNumber = arc4random_uniform(5) + 1
        label.text = "The sum is: \(firstNumber + secondNumber)"
        leftImage.image = UIImage(named: "Dice\(firstNumber)")
        rightImage.image = UIImage(named: "Dice\(secondNumber)")
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            let firstNumber = arc4random_uniform(5) + 1
            let secondNumber = arc4random_uniform(5) + 1
            label.text = "The sum is: \(firstNumber + secondNumber)"
            leftImage.image = UIImage(named: "Dice\(firstNumber)")
            rightImage.image = UIImage(named: "Dice\(secondNumber)")
        }
    }
}

